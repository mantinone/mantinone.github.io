This is a project I did at Learners Guild.

I had one week to build a browser-basec chess game.
The basic rules are complete, though I did not add algorithms for check and checkmate, and special rules such as Castling are not included.

To run the project, just open chess.html in your browser.  The styling works best in Chrome.