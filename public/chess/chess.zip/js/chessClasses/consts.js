const PAWN = 'pawn'
const ROOK = 'rook'
const KNIGHT = 'knight'
const BISHOP = 'bishop'
const QUEEN = 'queen'
const KING = 'king'

const BLACK = 'black'
const WHITE = 'white'
